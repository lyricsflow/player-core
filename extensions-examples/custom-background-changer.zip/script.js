let lastSongId = null;

function checkSongChange() {
  const metadata = window._spicySongMetadata;
  if (!metadata) return;

  const currentSongId = `${metadata.title}-${metadata.artist}`;
  if (currentSongId === lastSongId) return;

  lastSongId = currentSongId;
  changeBackground();
}

function changeBackground() {
  const colors = [
    'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
    'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
    'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
    'linear-gradient(135deg, #fa709a 0%, #fee140 100%)'
  ];
  
  const randomColor = colors[Math.floor(Math.random() * colors.length)];
  const dynamicBg = document.getElementById('dynamic-bg');
  if (dynamicBg) {
    dynamicBg.style.background = randomColor;
  }
}

setInterval(checkSongChange, 500);
