console.log('Custom Lyrics Provider extension loaded!');

function addCustomLyricsButton() {
  if (document.getElementById('custom-lyrics-btn')) return;

  const nowBar = document.getElementById('now-bar');
  if (!nowBar) return;

  const btn = document.createElement('button');
  btn.id = 'custom-lyrics-btn';
  btn.style.cssText = `
    background: rgba(255,255,255,0.1);
    border: none;
    color: white;
    padding: 8px 16px;
    border-radius: 8px;
    cursor: pointer;
    font-family: inherit;
    font-size: 13px;
    font-weight: 500;
    transition: background 0.2s ease;
  `;
  btn.textContent = 'Fetch Custom Lyrics';
  btn.onmouseenter = () => btn.style.background = 'rgba(255,255,255,0.15)';
  btn.onmouseleave = () => btn.style.background = 'rgba(255,255,255,0.1)';
  btn.onclick = fetchCustomLyrics;

  const settingsBtn = document.getElementById('btn-options');
  if (settingsBtn && settingsBtn.parentNode) {
    settingsBtn.parentNode.insertBefore(btn, settingsBtn.nextSibling);
  }
}

async function fetchCustomLyrics() {
  const metadata = window._spicySongMetadata;
  if (!metadata || !metadata.title || !metadata.artist) {
    alert('Please load a song first!');
    return;
  }

  try {
    alert('In a real extension, this would fetch lyrics from an API!');
    // Example API call:
    // const response = await fetch(`https://api.mylyrics.com/search?q=${encodeURIComponent(metadata.title + ' ' + metadata.artist)}`);
    // const data = await response.json();
    // Then parse into lyrics format...
  } catch (e) {
    console.error('Failed to fetch lyrics:', e);
    alert('Failed to fetch lyrics');
  }
}

addCustomLyricsButton();
setInterval(addCustomLyricsButton, 1000);
