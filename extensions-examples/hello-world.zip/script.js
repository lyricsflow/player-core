console.log('Hello from Hello World extension!');
console.log('Player object:', player);
console.log('Settings manager:', settingsManager);
