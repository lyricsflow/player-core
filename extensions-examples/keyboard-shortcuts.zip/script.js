document.addEventListener('keydown', (e) => {
  // Example: Press 'N' for next track
  if ((e.key === 'n' || e.key === 'N') && !e.ctrlKey && !e.metaKey && !e.altKey) {
    const nextBtn = document.getElementById('skip-forward');
    if (nextBtn) nextBtn.click();
  }
  
  // Example: Press 'P' for previous track
  if ((e.key === 'p' || e.key === 'P') && !e.ctrlKey && !e.metaKey && !e.altKey) {
    const prevBtn = document.getElementById('btn-backward');
    if (prevBtn) prevBtn.click();
  }
  
  // Example: Press 'Space' to toggle play/pause (if not already handled)
  if (e.key === ' ' && !e.ctrlKey && !e.metaKey && !e.altKey) {
    if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
      e.preventDefault();
      const playBtn = document.getElementById('btn-play-pause');
      if (playBtn) playBtn.click();
    }
  }
});

console.log('Custom keyboard shortcuts loaded!');
