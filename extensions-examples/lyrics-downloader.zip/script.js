function addLyricsDownloadButton() {
  // Check if button already exists
  if (document.getElementById('lyrics-download-btn')) return;

  const nowBar = document.getElementById('now-bar');
  if (!nowBar) return;

  const btn = document.createElement('button');
  btn.id = 'lyrics-download-btn';
  btn.style.cssText = `
    background: rgba(255,255,255,0.1);
    border: none;
    color: white;
    padding: 8px 16px;
    border-radius: 8px;
    cursor: pointer;
    font-family: inherit;
    font-size: 13px;
    font-weight: 500;
    transition: background 0.2s ease;
  `;
  btn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: middle; margin-right: 6px;"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"></path></svg> Download Lyrics`;
  
  btn.onmouseenter = () => btn.style.background = 'rgba(255,255,255,0.15)';
  btn.onmouseleave = () => btn.style.background = 'rgba(255,255,255,0.1)';
  btn.onclick = showDownloadMenu;

  // Insert near the settings button
  const settingsBtn = document.getElementById('btn-options');
  if (settingsBtn && settingsBtn.parentNode) {
    settingsBtn.parentNode.insertBefore(btn, settingsBtn.nextSibling);
  }
}

function showDownloadMenu() {
  const lyrics = window._spicyCurrentLyrics;
  const metadata = window._spicySongMetadata;
  
  if (!lyrics) {
    alert('No lyrics available to download');
    return;
  }

  // Create a simple menu
  const menu = document.createElement('div');
  menu.id = 'lyrics-download-menu';
  menu.style.cssText = `
    position: fixed;
    background: rgba(30,30,30,0.95);
    backdrop-filter: blur(20px);
    border-radius: 12px;
    padding: 8px 0;
    box-shadow: 0 10px 40px rgba(0,0,0,0.5);
    z-index: 100000;
    min-width: 200px;
  `;

  const options = [
    { label: 'Download as TTML', action: () => downloadTTML(lyrics, metadata) },
    { label: 'Download as Plain Text', action: () => downloadPlainText(lyrics, metadata) },
    { label: 'Download as LRC', action: () => downloadLRC(lyrics, metadata) }
  ];

  options.forEach(opt => {
    const item = document.createElement('div');
    item.style.cssText = `
      padding: 10px 20px;
      cursor: pointer;
      color: white;
      font-size: 14px;
      transition: background 0.15s ease;
    `;
    item.textContent = opt.label;
    item.onmouseenter = () => item.style.background = 'rgba(255,255,255,0.1)';
    item.onmouseleave = () => item.style.background = 'transparent';
    item.onclick = () => {
      opt.action();
      menu.remove();
    };
    menu.appendChild(item);
  });

  document.body.appendChild(menu);
  
  // Position the menu
  const btn = document.getElementById('lyrics-download-btn');
  const rect = btn.getBoundingClientRect();
  menu.style.left = `${rect.left}px`;
  menu.style.top = `${rect.bottom + 8}px`;

  // Close when clicking outside
  setTimeout(() => {
    document.addEventListener('click', function closeMenu(e) {
      if (!menu.contains(e.target) && e.target !== btn) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }
    });
  }, 0);
}

function downloadTTML(lyrics, metadata) {
  try {
    const ttml = window._spicyGenerateTTML(lyrics);
    const filename = `${metadata.title || 'lyrics'} - ${metadata.artist || 'unknown'}.ttml`;
    downloadFile(ttml, filename, 'application/ttml+xml');
  } catch (e) {
    console.error('Failed to generate TTML:', e);
    alert('Failed to download TTML');
  }
}

function downloadPlainText(lyrics, metadata) {
  let text = '';
  
  if (metadata.title) text += `${metadata.title}\n`;
  if (metadata.artist) text += `${metadata.artist}\n`;
  text += '\n';
  
  if (lyrics.Type === 'Static' && lyrics.Lines) {
    lyrics.Lines.forEach(line => {
      if (line.Text) text += line.Text + '\n';
    });
  } else if (lyrics.Content) {
    lyrics.Content.forEach(line => {
      if (line.Text) {
        text += line.Text + '\n';
      } else if (line.Lead && line.Lead.Syllables) {
        const lineText = line.Lead.Syllables.map(s => s.Text).join('');
        text += lineText + '\n';
      }
    });
  }
  
  const filename = `${metadata.title || 'lyrics'} - ${metadata.artist || 'unknown'}.txt`;
  downloadFile(text, filename, 'text/plain');
}

function downloadLRC(lyrics, metadata) {
  let lrc = '';
  
  if (metadata.title) lrc += `[ti:${metadata.title}]\n`;
  if (metadata.artist) lrc += `[ar:${metadata.artist}]\n`;
  if (metadata.album) lrc += `[al:${metadata.album}]\n`;
  lrc += '\n';
  
  if (lyrics.Content) {
    lyrics.Content.forEach(line => {
      const time = line.Start || 0;
      const minutes = Math.floor(time / 60000);
      const seconds = ((time % 60000) / 1000).toFixed(2);
      const timeStr = `[${String(minutes).padStart(2, '0')}:${String(seconds).padStart(5, '0')}]`;
      
      let lineText = '';
      if (line.Text) {
        lineText = line.Text;
      } else if (line.Lead && line.Lead.Syllables) {
        lineText = line.Lead.Syllables.map(s => s.Text).join('');
      }
      
      if (lineText) {
        lrc += `${timeStr}${lineText}\n`;
      }
    });
  }
  
  const filename = `${metadata.title || 'lyrics'} - ${metadata.artist || 'unknown'}.lrc`;
  downloadFile(lrc, filename, 'text/plain');
}

function downloadFile(content, filename, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename.replace(/[<>:"/\\|?*]/g, '');
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Try adding the button on load and also periodically in case DOM changes
addLyricsDownloadButton();
setInterval(addLyricsDownloadButton, 1000);
