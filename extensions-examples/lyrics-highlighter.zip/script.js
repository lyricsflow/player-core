function addCustomStyles() {
  if (document.getElementById('lyrics-highlighter-styles')) return;
  
  const style = document.createElement('style');
  style.id = 'lyrics-highlighter-styles';
  style.textContent = `
    .active-lyric-line {
      text-shadow: 0 0 20px rgba(255, 105, 180, 0.8) !important;
      color: #ff69b4 !important;
    }
  `;
  document.head.appendChild(style);
}

addCustomStyles();
