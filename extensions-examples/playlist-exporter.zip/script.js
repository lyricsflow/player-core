console.log('Playlist Exporter extension loaded!');

function addExportButton() {
  if (document.getElementById('playlist-export-btn')) return;

  const queuePanel = document.getElementById('queue-panel');
  if (!queuePanel) return;

  const queueHeader = queuePanel.querySelector('.QueueHeader');
  if (!queueHeader) return;

  const btn = document.createElement('button');
  btn.id = 'playlist-export-btn';
  btn.style.cssText = `
    background: transparent;
    border: none;
    color: white;
    padding: 6px 12px;
    border-radius: 6px;
    cursor: pointer;
    font-family: inherit;
    font-size: 12px;
    font-weight: 500;
    transition: background 0.2s ease;
  `;
  btn.textContent = 'Export';
  btn.onmouseenter = () => btn.style.background = 'rgba(255,255,255,0.1)';
  btn.onmouseleave = () => btn.style.background = 'transparent';
  btn.onclick = showExportMenu;

  const queueActions = queueHeader.querySelector('.QueueActions');
  if (queueActions) {
    queueActions.insertBefore(btn, queueActions.firstChild);
  }
}

function showExportMenu() {
  const menu = document.createElement('div');
  menu.id = 'playlist-export-menu';
  menu.style.cssText = `
    position: fixed;
    background: rgba(30,30,30,0.95);
    backdrop-filter: blur(20px);
    border-radius: 12px;
    padding: 8px 0;
    box-shadow: 0 10px 40px rgba(0,0,0,0.5);
    z-index: 100000;
    min-width: 200px;
  `;

  const options = [
    { label: 'Export as M3U', action: exportAsM3U },
    { label: 'Export as TXT', action: exportAsTXT }
  ];

  options.forEach(opt => {
    const item = document.createElement('div');
    item.style.cssText = `
      padding: 10px 20px;
      cursor: pointer;
      color: white;
      font-size: 14px;
      transition: background 0.15s ease;
    `;
    item.textContent = opt.label;
    item.onmouseenter = () => item.style.background = 'rgba(255,255,255,0.1)';
    item.onmouseleave = () => item.style.background = 'transparent';
    item.onclick = () => {
      opt.action();
      menu.remove();
    };
    menu.appendChild(item);
  });

  document.body.appendChild(menu);
  
  const btn = document.getElementById('playlist-export-btn');
  const rect = btn.getBoundingClientRect();
  menu.style.left = `${rect.left}px`;
  menu.style.top = `${rect.bottom + 8}px`;

  setTimeout(() => {
    document.addEventListener('click', function closeMenu(e) {
      if (!menu.contains(e.target) && e.target !== btn) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }
    });
  }, 0);
}

async function exportAsM3U() {
  const queue = await getQueueFromPlayer();
  if (!queue || queue.length === 0) {
    alert('No playlist to export!');
    return;
  }

  let m3u = '#EXTM3U\n';
  queue.forEach(track => {
    m3u += `#EXTINF:-1,${track.artist || 'Unknown Artist'} - ${track.name || 'Unknown Title'}\n`;
    m3u += `${track.name || 'unknown'}\n`;
  });

  downloadFile(m3u, 'playlist.m3u', 'audio/mpegurl');
}

async function exportAsTXT() {
  const queue = await getQueueFromPlayer();
  if (!queue || queue.length === 0) {
    alert('No playlist to export!');
    return;
  }

  let txt = '';
  queue.forEach((track, index) => {
    txt += `${index + 1}. ${track.artist || 'Unknown Artist'} - ${track.name || 'Unknown Title'}\n`;
  });

  downloadFile(txt, 'playlist.txt', 'text/plain');
}

async function getQueueFromPlayer() {
  try {
    // Try to get queue from window or from the player
    const router = await import('./js/router.js');
    if (router && router.getQueue) {
      return await router.getQueue();
    }
  } catch (e) {
    console.error('Failed to get queue:', e);
  }
  return null;
}

function downloadFile(content, filename, mimeType) {
  const blob = new Blob([content], { type: mimeType || 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

addExportButton();
setInterval(addExportButton, 1000);
