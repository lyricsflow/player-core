let sleepTimerInterval = null;
let remainingTime = 0;

function addSleepTimerButton() {
  if (document.getElementById('sleep-timer-btn')) return;

  const nowBar = document.getElementById('now-bar');
  if (!nowBar) return;

  const btn = document.createElement('button');
  btn.id = 'sleep-timer-btn';
  btn.style.cssText = `
    background: rgba(255,255,255,0.1);
    border: none;
    color: white;
    padding: 8px 16px;
    border-radius: 8px;
    cursor: pointer;
    font-family: inherit;
    font-size: 13px;
    font-weight: 500;
    transition: background 0.2s ease;
  `;
  btn.textContent = 'Sleep Timer';
  btn.onmouseenter = () => btn.style.background = 'rgba(255,255,255,0.15)';
  btn.onmouseleave = () => btn.style.background = 'rgba(255,255,255,0.1)';
  btn.onclick = showSleepTimerMenu;

  const settingsBtn = document.getElementById('btn-options');
  if (settingsBtn && settingsBtn.parentNode) {
    settingsBtn.parentNode.insertBefore(btn, settingsBtn.nextSibling);
  }
}

function showSleepTimerMenu() {
  if (document.getElementById('sleep-timer-menu')) return;

  const menu = document.createElement('div');
  menu.id = 'sleep-timer-menu';
  menu.style.cssText = `
    position: fixed;
    background: rgba(30,30,30,0.95);
    backdrop-filter: blur(20px);
    border-radius: 12px;
    padding: 16px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.5);
    z-index: 100000;
    min-width: 250px;
  `;

  menu.innerHTML = `
    <h3 style="color: white; margin: 0 0 12px 0;">Sleep Timer</h3>
    <div style="margin-bottom: 12px;">
      <label style="color: rgba(255,255,255,0.7); font-size: 13px;">Minutes:</label>
      <input type="number" id="sleep-timer-minutes" value="30" style="width: 100%; padding: 8px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.2); background: rgba(255,255,255,0.05); color: white; margin-top: 4px;">
    </div>
    <button id="sleep-timer-start" style="width: 100%; padding: 10px; border-radius: 8px; border: none; background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); color: white; font-weight: 600; cursor: pointer; margin-bottom: 8px;">Start Timer</button>
    <button id="sleep-timer-cancel" style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.2); background: transparent; color: white; cursor: pointer;">Cancel Timer</button>
    <div id="sleep-timer-status" style="color: rgba(255,255,255,0.7); font-size: 13px; margin-top: 8px;"></div>
  `;

  document.body.appendChild(menu);

  const btn = document.getElementById('sleep-timer-btn');
  const rect = btn.getBoundingClientRect();
  menu.style.left = `${rect.left}px`;
  menu.style.top = `${rect.bottom + 8}px`;

  document.getElementById('sleep-timer-start').onclick = startSleepTimer;
  document.getElementById('sleep-timer-cancel').onclick = cancelSleepTimer;

  setTimeout(() => {
    document.addEventListener('click', function closeMenu(e) {
      if (!menu.contains(e.target) && e.target !== btn) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }
    });
  }, 0);
}

function startSleepTimer() {
  const minutesInput = document.getElementById('sleep-timer-minutes');
  const minutes = parseInt(minutesInput.value);
  
  if (isNaN(minutes) || minutes <= 0) {
    alert('Please enter a valid number of minutes');
    return;
  }

  remainingTime = minutes * 60;
  updateSleepTimerStatus();

  if (sleepTimerInterval) clearInterval(sleepTimerInterval);
  
  sleepTimerInterval = setInterval(() => {
    remainingTime--;
    updateSleepTimerStatus();
    
    if (remainingTime <= 0) {
      cancelSleepTimer();
      if (player && player.pause) {
        player.pause();
      }
      alert('Sleep timer ended! Playback stopped.');
    }
  }, 1000);

  const menu = document.getElementById('sleep-timer-menu');
  if (menu) menu.remove();
}

function cancelSleepTimer() {
  if (sleepTimerInterval) {
    clearInterval(sleepTimerInterval);
    sleepTimerInterval = null;
  }
  remainingTime = 0;
  updateSleepTimerStatus();
}

function updateSleepTimerStatus() {
  const statusEl = document.getElementById('sleep-timer-status');
  if (statusEl) {
    if (remainingTime > 0) {
      const mins = Math.floor(remainingTime / 60);
      const secs = remainingTime % 60;
      statusEl.textContent = `Remaining: ${mins}:${String(secs).padStart(2, '0')}`;
    } else {
      statusEl.textContent = '';
    }
  }
  
  const btn = document.getElementById('sleep-timer-btn');
  if (btn) {
    if (remainingTime > 0) {
      const mins = Math.floor(remainingTime / 60);
      const secs = remainingTime % 60;
      btn.textContent = `${mins}:${String(secs).padStart(2, '0')}`;
    } else {
      btn.textContent = 'Sleep Timer';
    }
  }
}

addSleepTimerButton();
setInterval(addSleepTimerButton, 1000);
